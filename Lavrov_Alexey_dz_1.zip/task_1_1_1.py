"""
Урок 1. Знакомство с Python
1. Реализовать вывод информации о промежутке времени в зависимости от его
продолжительности duration в секундах:
до минуты: <s> сек;
* до часа: <m> мин <s> сек;
* до суток: <h> час <m> мин <s> сек;
** до месяца, до года, больше года: по аналогии.

Вариант 1 - реализация без цикла
"""

# заводим константы для пересчета интервалов
SEK_IN_MIN, MIN_IN_HOUR, HOUR_IN_DAY, DAY_IN_MONTH, MONTH_IN_YEAR = \
    60, 60, 24, (3 * 365 / 12 + 366 / 12) / 4, 12
# получаем с консоли целое число (исключения не ловим), берем его по модулю
duration_in_sek = abs(int(input('Введите интервал времени в секундах (целое '
                                'положительное число) для конвертации: ')))
# последовательно переводим интервалы в минуты, часы, дни
# с помощью операций // и %
duration_min, duration_sek = duration_in_sek // SEK_IN_MIN, \
                             duration_in_sek % SEK_IN_MIN
duration_hour, duration_min = duration_min // MIN_IN_HOUR, \
                              duration_min % MIN_IN_HOUR
duration_day, duration_hour = duration_hour // HOUR_IN_DAY, \
                              duration_hour % HOUR_IN_DAY
# по ТЗ не детализировалось, поэтому длительность месяца в днях берем
# как (3 * 365 / 12 + 366 / 12) / 4 с округлением рез-та
duration_month, duration_day = round(duration_day // DAY_IN_MONTH), \
                               round(duration_day % DAY_IN_MONTH)
duration_year, duration_month = duration_month // MONTH_IN_YEAR, \
                                duration_month % MONTH_IN_YEAR

# вывод инфы - выводим по ТЗ, начиная с ненулевого старшего периода
if duration_year > 0:
    print(f"\n{duration_year} лет {duration_month} мес {duration_day} дн "
          f"{duration_hour} час {duration_min} мин {duration_sek} сек")
elif duration_month > 0:
    print(f"\n{duration_month} мес {duration_day} дн {duration_hour} час "
          f"{duration_min} мин {duration_sek} сек")
elif duration_day > 0:
    print(f"\n{duration_day} дн {duration_hour} час {duration_min} мин "
          f"{duration_sek} сек")
elif duration_hour > 0:
    print(f"\n{duration_hour} час {duration_min} мин {duration_sek} сек")
elif duration_min > 0:
    print(f"\n{duration_min} мин {duration_sek} сек")
else:
    print(f"\n{duration_sek} сек")

print("\n* Для расчета кол-ва месяцев - берем усредненное значение дней",
      "в месяце с учетом високосных лет (3 * 365 / 12 + 366 / 12) / 4 = "
      "30,4375 дней", sep="\n")