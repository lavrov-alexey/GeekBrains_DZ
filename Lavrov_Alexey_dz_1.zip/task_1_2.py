"""
Урок 1. Знакомство с Python
2. Создать список, состоящий из кубов нечётных чисел от 0 до 1000:
a. Вычислить сумму тех чисел из этого списка, сумма цифр которых делится нацело на 7.
Например, число «19 ^ 3 = 6859» будем включать в сумму, так как 6 + 8 + 5 + 9 = 28
– делится нацело на 7.
Внимание: использовать только арифметические операции!
b. К каждому элементу списка добавить 17 и заново вычислить сумму тех чисел из
этого списка, сумма цифр которых делится нацело на 7.
c. *Решить задачу под пунктом b не создавая новый список!
"""

MAX_COUNT = 1000
DIVISOR = 7
lst_cubs_numbers = []

# генерируем список кубов нечетных чисел
for count in range(1, MAX_COUNT + 1, 2):
    lst_cubs_numbers.append(count ** 3)

# заводим переменные для накопления искомых сумм по задачам a и b
sum_numbers_divisor, sum_numbers_divisor_plus17 = 0, 0
# перебираем все числа из списка кубов нечетных чисел
for current_number in lst_cubs_numbers:
    # для каждого нового числа обнуляем сумму его цифр
    sum_digit_of_number, temp_number = 0, current_number
    sum_digit_of_number_plus17, temp_number_plus17 = 0, current_number + 17
    # temp_number_plus17 всегда больше, поэтому строим цикл по нему
    # в цикле отбираем по 1 младшему разряду чисел (по задачам a и b)
    # и плюсуем к сумме его цифр
    while temp_number_plus17 != 0:
        # контрольные принты
        # print(f"temp_number={temp_number}, sum_digit_of_number="
        #       f"{sum_digit_of_number}")
        # print(f"temp_number_plus17={temp_number_plus17}, "
        #       f"sum_digit_of_number_plus17={sum_digit_of_number_plus17}")
        sum_digit_of_number += temp_number % 10
        temp_number = temp_number // 10
        sum_digit_of_number_plus17 += temp_number_plus17 % 10
        temp_number_plus17 = temp_number_plus17 // 10
    # на выходе из while в sum_digit_of_number сумма цифр текущего числа из списка
    # кубов нечетных если сумма цифр текущ. числа делится на DIVISOR без
    # остатка - суммируем его
    if sum_digit_of_number % DIVISOR == 0:
        sum_numbers_divisor += current_number
    if sum_digit_of_number_plus17 % DIVISOR == 0:
        sum_numbers_divisor_plus17 += current_number + 17
print(f"\nСумма чисел ряда из кубов нечетных чисел от 1 до 1000, сумма цифр",
      f"которых делится на {DIVISOR}: {sum_numbers_divisor}", sep="\n")
print(f"\nСумма чисел ряда из кубов нечетных чисел (плюс 17 к каждому) ",
      f"от 1 до 1000, сумма цифр которых делится на {DIVISOR}: "
      f"{sum_numbers_divisor_plus17}", sep="\n")
